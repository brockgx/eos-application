### INSTALLATION STEPS ###
1. Check the configuration file and modify the details
2. Check the contents of PassIV (ensure the server and agent are identical)
3. Run EosServerLinux